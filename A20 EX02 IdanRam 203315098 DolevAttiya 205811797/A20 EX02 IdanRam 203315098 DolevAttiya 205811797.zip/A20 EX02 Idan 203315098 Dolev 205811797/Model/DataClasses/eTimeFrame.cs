﻿namespace A20_EX02_Idan_203315098_Dolev_205811797.Model.DataClasses
{
    public enum eTimeFrame
    {
        Week = 7,
        Month = 31,
        Year = 365
    }
}
